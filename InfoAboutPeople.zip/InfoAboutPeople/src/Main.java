public class Main {
    public static void main(String[] args) {
        System.out.println("Balakan Denys Viktorovych");
        System.out.println("age - 24");
        System.out.println("height - 184 cm.");
        System.out.println();
        System.out.println("Oleksyuk Liliia Vadimovna");
        System.out.println("age - 21");
        System.out.println("height - 167 cm");
        System.out.println();
        System.out.println("Olen Roman Anatolyovich");
        System.out.println("age - 23");
        System.out.println("height - 180 cm");
        System.out.println();
        System.out.printf("%.2f, %.2f, %.2f", 3.222, 4.333, 5.444);
        System.out.println();
        System.out.println();
        System.out.print("|   ");
        System.out.print("|");
        System.out.println();
        System.out.print("|   ");
        System.out.println("|");
        System.out.println();
        System.out.print("|     ");
        System.out.print("|");
    }
}